function submitbtn(){
	var radios = document.getElementsByName('star');
	var rate;
	for (var i = 0, length = radios.length; i < length; i++) {
    if (radios[i].checked) {
        rate = (radios[i].value);
		break;
    }
}
		
	//alert (document.getElementById("msg").value);
	if((document.getElementById("name").value)==""){
		alert ("Please Enter Your Name");
	}else if((document.getElementById("msg").value)==""){
		alert ("Please Enter Your Comment");
	}else if(rate==null){
		alert("Please rate us");
	}else if(ValidateEmail(document.getElementById("email").value)){
		alert("Please enter a valid e-mail");
	}else
		{
	var para = document.createElement("H3");
	var msg = ((document.getElementById("msg").value)+" - "+(document.getElementById("name").value));
    var t = document.createTextNode(msg);
    para.appendChild(t);
    document.getElementById("recentComments").appendChild(para);
		
		document.getElementById("popupheading").innerHTML = 
		("Dear "+document.getElementById("name").value+", Thanks you for your feedback. You rated our website "+
		rate+" and your comment was \""+document.getElementById("msg").value+"\"");
	
		var modal = document.getElementById('myModal');
		modal.style.display = "block";
	}
}
function closedialog() {
    var modal = document.getElementById('myModal');
	modal.style.display = "none";

}

function ValidateEmail(mail) {
 if ((/^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/).test(mail)){
    return (false)
  }else
    return (true)
}
